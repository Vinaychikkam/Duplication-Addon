import bpy
import os
import re

# Helper function to generate an incremented name
def get_incremented_name(base_name):
    match = re.search(r"(.+?)(\d*)$", base_name)
    if match:
        name = match.group(1)
        number = match.group(2)
        new_number = int(number) + 1 if number else 1
        return f"{name}{new_number}"
    return f"{base_name}1"

# Save file with incremented or suffix-based name
def save_file_with_suffix(suffix):
    if not bpy.data.filepath:
        bpy.ops.wm.call_menu(name="ERROR_MT_unsaved_file")
        return {'CANCELLED'}

    base_name = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
    if suffix == "Increment":
        suffix = get_incremented_name(base_name)
    else:
        suffix = f"{base_name}_{suffix}"

    new_filepath = bpy.path.abspath(f"//{suffix}.blend")
    bpy.ops.wm.save_as_mainfile(filepath=new_filepath)
    return {'FINISHED'}

# Duplicate objects while preserving parenting and materials
def duplicate_selected_objects(suffix):
    selected_objects = bpy.context.selected_objects
    new_objects = {}

    for obj in selected_objects:
        new_name = get_incremented_name(obj.name) if suffix == "Increment" else f"{obj.name}_{suffix}"
        new_obj = obj.copy()
        new_obj.data = obj.data.copy()
        new_obj.name = new_name

        # Preserve materials
        if obj.data.materials:
            new_obj.data.materials.clear()
            mat_mapping = {}

            for i, mat in enumerate(obj.data.materials):
                if mat:
                    new_mat_name = get_incremented_name(mat.name) if suffix == "Increment" else f"{mat.name}_{suffix}"
                    if new_mat_name not in mat_mapping:
                        new_mat = mat.copy()
                        new_mat.name = new_mat_name
                        mat_mapping[new_mat_name] = new_mat

                    new_obj.data.materials.append(mat_mapping[new_mat_name])

            for poly in new_obj.data.polygons:
                poly.material_index = obj.data.polygons[poly.index].material_index  

        bpy.context.collection.objects.link(new_obj)
        new_objects[obj] = new_obj  

    # Preserve parenting
    for old_obj, new_obj in new_objects.items():
        if old_obj.parent:
            new_obj.parent = new_objects.get(old_obj.parent, old_obj.parent)
            new_obj.matrix_parent_inverse = old_obj.matrix_parent_inverse

# Pie menu for suffix selection
class OBJECT_MT_pie_menu(bpy.types.Menu):
    bl_label = "Naming Options"
    bl_idname = "OBJECT_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        suffixes = ["Increment", "Start", "In Progress", "Pre Final", "Final", "Best"]

        if context.area.type == 'VIEW_3D':
            for suffix in suffixes:
                pie.operator("wm.save_file_with_suffix", text=suffix).suffix = suffix

        elif context.area.type == 'OUTLINER':
            for suffix in suffixes:
                pie.operator("object.duplicate_with_suffix", text=suffix).suffix = suffix

# Warning for unsaved file
class ERROR_MT_unsaved_file(bpy.types.Menu):
    bl_label = "Save Your File First"
    bl_idname = "ERROR_MT_unsaved_file"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Error: Please save your file first!")

# Operators
class WM_OT_save_file_with_suffix(bpy.types.Operator):
    bl_idname = "wm.save_file_with_suffix"
    bl_label = "Save File with Suffix"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        return save_file_with_suffix(self.suffix)

class OBJECT_OT_duplicate_with_suffix(bpy.types.Operator):
    bl_idname = "object.duplicate_with_suffix"
    bl_label = "Duplicate Object with Suffix"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        duplicate_selected_objects(self.suffix)
        return {'FINISHED'}

# Addon Preferences for user-defined shortcuts
class NamingAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    save_hotkey: bpy.props.StringProperty(
        name="Save Pie Menu Hotkey",
        description="Enter a hotkey for saving file pie menu",
        default="Shift N"
    )

    duplicate_hotkey: bpy.props.StringProperty(
        name="Duplicate Pie Menu Hotkey",
        description="Enter a hotkey for duplicating objects pie menu",
        default="Ctrl Shift N"
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Customize Shortcut Keys:")
        layout.prop(self, "save_hotkey")
        layout.prop(self, "duplicate_hotkey")
        layout.operator("wm.apply_custom_hotkeys")

# Operator to update keymaps when user changes preferences
class WM_OT_apply_custom_hotkeys(bpy.types.Operator):
    bl_idname = "wm.apply_custom_hotkeys"
    bl_label = "Apply Custom Hotkeys"

    def execute(self, context):
        update_keymaps()
        return {'FINISHED'}

# Registering keymaps
addon_keymaps = []

def update_keymaps():
    global addon_keymaps

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    prefs = bpy.context.preferences.addons[__name__].preferences
    wm = bpy.context.window_manager

    def parse_keymap_string(hotkey_string):
        keys = hotkey_string.upper().split()
        key = keys[-1]
        modifiers = {"shift": False, "ctrl": False, "alt": False, "oskey": False}

        for mod in keys[:-1]:
            if mod in ["SHIFT", "CTRL", "ALT", "OSKEY"]:
                modifiers[mod.lower()] = True

        if key not in bpy.types.KeyMapItem.bl_rna.properties["type"].enum_items.keys():
            print(f"Invalid key '{key}' in custom hotkey: {hotkey_string}")
            return None, None

        return key, modifiers

    save_key, save_mods = parse_keymap_string(prefs.save_hotkey)
    duplicate_key, duplicate_mods = parse_keymap_string(prefs.duplicate_hotkey)

    if save_key:
        km_viewport = wm.keyconfigs.addon.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi_save = km_viewport.keymap_items.new("wm.call_menu_pie", save_key, "PRESS", **save_mods)
        kmi_save.properties.name = "OBJECT_MT_pie_menu"
        addon_keymaps.append((km_viewport, kmi_save))

    if duplicate_key:
        km_outliner = wm.keyconfigs.addon.keymaps.new(name="Outliner", space_type="OUTLINER")
        kmi_duplicate = km_outliner.keymap_items.new("wm.call_menu_pie", duplicate_key, "PRESS", **duplicate_mods)
        kmi_duplicate.properties.name = "OBJECT_MT_pie_menu"
        addon_keymaps.append((km_outliner, kmi_duplicate))

def register():
    bpy.utils.register_class(NamingAddonPreferences)
    bpy.utils.register_class(OBJECT_MT_pie_menu)
    bpy.utils.register_class(WM_OT_save_file_with_suffix)
    bpy.utils.register_class(OBJECT_OT_duplicate_with_suffix)
    bpy.utils.register_class(ERROR_MT_unsaved_file)
    bpy.utils.register_class(WM_OT_apply_custom_hotkeys)
    update_keymaps()

def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.utils.unregister_class(NamingAddonPreferences)
    bpy.utils.unregister_class(OBJECT_MT_pie_menu)
    bpy.utils.unregister_class(WM_OT_save_file_with_suffix)
    bpy.utils.unregister_class(OBJECT_OT_duplicate_with_suffix)
    bpy.utils.unregister_class(ERROR_MT_unsaved_file)
    bpy.utils.unregister_class(WM_OT_apply_custom_hotkeys)

if __name__ == "__main__":
    register()
