import bpy

# Function to save blend file with a chosen suffix
def save_blend_file_with_suffix(suffix):
    if bpy.data.filepath:
        new_filepath = bpy.data.filepath.replace(".blend", f"_{suffix}.blend")
        bpy.ops.wm.save_as_mainfile(filepath=new_filepath)
    else:
        self.report({'ERROR'}, "Please save the file first.")

# Function to duplicate selected objects in Outliner with materials and chosen suffix
def duplicate_objects_with_suffix_and_materials(suffix):
    for obj in bpy.context.selected_objects:
        new_obj = obj.copy()
        new_obj.data = obj.data.copy()
        new_obj.name = f"{obj.name}_{suffix}"
        # Duplicate materials
        if obj.material_slots:
            new_obj.data.materials.clear()
            for slot in obj.material_slots:
                if slot.material:
                    new_mat = slot.material.copy()
                    new_mat.name = f"{slot.material.name}_{suffix}"
                    new_obj.data.materials.append(new_mat)
        bpy.context.collection.objects.link(new_obj)

# Pie menu for suffix selection
class OBJECT_MT_pie_menu(bpy.types.Menu):
    bl_label = "Select Naming Suffix"
    bl_idname = "OBJECT_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        suffixes = ["Increment", "Start", "In Progress", "Pre Final", "Final", "Best"]

        for suffix in suffixes:
            if context.area.type == 'VIEW_3D':  # Layout
                pie.operator("wm.save_file_with_suffix", text=suffix).suffix = suffix
            elif context.area.type == 'OUTLINER':  # Outliner
                pie.operator("object.duplicate_with_suffix", text=suffix).suffix = suffix

# Operator for saving blend file in Layout
class WM_OT_save_file_with_suffix(bpy.types.Operator):
    bl_idname = "wm.save_file_with_suffix"
    bl_label = "Save Blend File with Suffix"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        save_blend_file_with_suffix(self.suffix)
        return {'FINISHED'}

# Operator for duplicating with suffix and materials in Outliner
class OBJECT_OT_duplicate_with_suffix(bpy.types.Operator):
    bl_idname = "object.duplicate_with_suffix"
    bl_label = "Duplicate with Suffix and Materials"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        duplicate_objects_with_suffix_and_materials(self.suffix)
        return {'FINISHED'}

addon_keymaps = []

def register():
    bpy.utils.register_class(OBJECT_MT_pie_menu)
    bpy.utils.register_class(WM_OT_save_file_with_suffix)
    bpy.utils.register_class(OBJECT_OT_duplicate_with_suffix)

    wm = bpy.context.window_manager

    # Shift+N in Layout
    km_layout = wm.keyconfigs.addon.keymaps.new(name="3D View", space_type="VIEW_3D")
    kmi_shift_n_layout = km_layout.keymap_items.new("wm.call_menu_pie", "N", "PRESS", shift=True)
    kmi_shift_n_layout.properties.name = "OBJECT_MT_pie_menu"
    addon_keymaps.append((km_layout, kmi_shift_n_layout))

    # Ctrl+Shift+N in Outliner
    km_outliner = wm.keyconfigs.addon.keymaps.new(name="Outliner", space_type="OUTLINER")
    kmi_ctrl_shift_n_outliner = km_outliner.keymap_items.new("wm.call_menu_pie", "N", "PRESS", ctrl=True, shift=True)
    kmi_ctrl_shift_n_outliner.properties.name = "OBJECT_MT_pie_menu"
    addon_keymaps.append((km_outliner, kmi_ctrl_shift_n_outliner))

def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.utils.unregister_class(OBJECT_MT_pie_menu)
    bpy.utils.unregister_class(WM_OT_save_file_with_suffix)
    bpy.utils.unregister_class(OBJECT_OT_duplicate_with_suffix)

if __name__ == "__main__":
    register()
