import bpy
import os
import re

# Helper function to generate an incremented name if needed
def get_incremented_name(base_name):
    match = re.search(r"(.+?)(\d*)$", base_name)
    if match:
        name = match.group(1)
        number = match.group(2)
        new_number = int(number) + 1 if number else 1
        return f"{name}{new_number}"
    return f"{base_name}1"

# Save file with incremented or suffix-based name
def save_file_with_suffix(suffix):
    if not bpy.data.filepath:  # Check if the file is unnamed
        bpy.ops.wm.call_menu(name="ERROR_MT_unsaved_file")
        return {'CANCELLED'}
    
    base_name = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
    if suffix == "Increment":
        suffix = get_incremented_name(base_name)
    else:
        suffix = f"{base_name}_{suffix}"
    new_filepath = bpy.path.abspath(f"//{suffix}.blend")
    bpy.ops.wm.save_as_mainfile(filepath=new_filepath)
    return {'FINISHED'}

# Duplicate object with incremented name and modified material names
def duplicate_object_with_suffix(suffix):
    for obj in bpy.context.selected_objects:
        new_name = get_incremented_name(obj.name) if suffix == "Increment" else f"{obj.name}_{suffix}"
        new_obj = obj.copy()
        new_obj.data = obj.data.copy()
        new_obj.name = new_name

        # Update material names based on suffix or increment
        if obj.material_slots:
            new_obj.data.materials.clear()
            for slot in obj.material_slots:
                if slot.material:
                    # Use incremental naming only for 'Increment' option; otherwise, apply the suffix
                    if suffix == "Increment":
                        new_mat_name = get_incremented_name(slot.material.name)
                    else:
                        new_mat_name = f"{slot.material.name}_{suffix}"
                    new_mat = slot.material.copy()
                    new_mat.name = new_mat_name
                    new_obj.data.materials.append(new_mat)

        bpy.context.collection.objects.link(new_obj)

# Pie menu for suffix selection
class OBJECT_MT_pie_menu(bpy.types.Menu):
    bl_label = "Naming Options"
    bl_idname = "OBJECT_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        suffixes = ["Increment", "Start", "In Progress", "Pre Final", "Final", "Best"]
        for suffix in suffixes:
            if context.area.type == 'VIEW_3D':
                pie.operator("wm.save_file_with_suffix", text=suffix).suffix = suffix
            elif context.area.type == 'OUTLINER':
                pie.operator("object.duplicate_with_suffix", text=suffix).suffix = suffix

# Warning for unsaved file
class ERROR_MT_unsaved_file(bpy.types.Menu):
    bl_label = "Save Your File First"
    bl_idname = "ERROR_MT_unsaved_file"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Error: Please save your file first!")

# Operators for each behavior
class WM_OT_save_file_with_suffix(bpy.types.Operator):
    bl_idname = "wm.save_file_with_suffix"
    bl_label = "Save File with Suffix"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        result = save_file_with_suffix(self.suffix)
        return result

class OBJECT_OT_duplicate_with_suffix(bpy.types.Operator):
    bl_idname = "object.duplicate_with_suffix"
    bl_label = "Duplicate Object with Suffix"
    suffix: bpy.props.StringProperty()

    def execute(self, context):
        duplicate_object_with_suffix(self.suffix)
        return {'FINISHED'}

# Registering keymaps
addon_keymaps = []

def register():
    bpy.utils.register_class(OBJECT_MT_pie_menu)
    bpy.utils.register_class(WM_OT_save_file_with_suffix)
    bpy.utils.register_class(OBJECT_OT_duplicate_with_suffix)
    bpy.utils.register_class(ERROR_MT_unsaved_file)

    wm = bpy.context.window_manager
    km_layout = wm.keyconfigs.addon.keymaps.new(name="3D View", space_type="VIEW_3D")
    kmi_shift_n_layout = km_layout.keymap_items.new("wm.call_menu_pie", "N", "PRESS", shift=True)
    kmi_shift_n_layout.properties.name = "OBJECT_MT_pie_menu"
    addon_keymaps.append((km_layout, kmi_shift_n_layout))

    km_outliner = wm.keyconfigs.addon.keymaps.new(name="Outliner", space_type="OUTLINER")
    kmi_ctrl_shift_n_outliner = km_outliner.keymap_items.new("wm.call_menu_pie", "N", "PRESS", ctrl=True, shift=True)
    kmi_ctrl_shift_n_outliner.properties.name = "OBJECT_MT_pie_menu"
    addon_keymaps.append((km_outliner, kmi_ctrl_shift_n_outliner))

def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.utils.unregister_class(OBJECT_MT_pie_menu)
    bpy.utils.unregister_class(WM_OT_save_file_with_suffix)
    bpy.utils.unregister_class(OBJECT_OT_duplicate_with_suffix)
    bpy.utils.unregister_class(ERROR_MT_unsaved_file)

if __name__ == "__main__":
    register()
